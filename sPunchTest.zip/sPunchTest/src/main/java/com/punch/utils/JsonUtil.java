package com.punch.utils;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/****
 * Utility class to convert json to map
 * @author Akash
 *
 */
public class JsonUtil {
	
	private static final Logger LOGGER = LogManager.getLogger(JsonUtil.class);
	public static Map<String, Object> toMap(JSONObject jsonobj)  throws JSONException {
        Map<String, Object> map = new HashMap<String, Object>();
        Iterator<String> keys = jsonobj.keys();
        while(keys.hasNext()) {
            String key = keys.next();
            Object value = jsonobj.get(key);
            if (value != null) {
	            if (value instanceof JSONArray) {
	                value = toList((JSONArray) value);
	                map.put(key, value);
	            } else if (value instanceof JSONObject) {
	                value = toMap((JSONObject) value);
	                map.put(key, value);
	            } else if (value instanceof Integer) {
	            	map.put(key, value.toString());
	            } else {
	            	map.put(key, value);
	            }
            } else {
            	map.put(key, "");
            }
            
        }   return map;
    }
	
	public static List<Object> toList(JSONArray array) throws JSONException {
        List<Object> list = new ArrayList<Object>();
        for(int i = 0; i < array.length(); i++) {
            Object value = array.get(i);
            if (value instanceof JSONArray) {
                value = toList((JSONArray) value);
            }
            else if (value instanceof JSONObject) {
                value = toMap((JSONObject) value);
            }
            list.add(value);
        }   return list;
	}
	
	@SuppressWarnings("unchecked")
	public static org.json.simple.JSONArray toJson(List<Object> list) {
		org.json.simple.JSONArray jsonArray = new org.json.simple.JSONArray();

        for (Object obj : list) {
            if (obj instanceof Map) {
                jsonArray.add(toJson((Map) obj));
            }
            else if (obj instanceof List) {
                jsonArray.add(toJson((List) obj));
            }
            else {
                jsonArray.add(obj);
            }
        }

        return jsonArray;
    }
	
	@SuppressWarnings("unchecked")
	public static org.json.simple.JSONArray toJsonV2(List<Map<String, Object>> list) {
		org.json.simple.JSONArray jsonArray = new org.json.simple.JSONArray();

        for (Object obj : list) {
            if (obj instanceof Map) {
                jsonArray.add(toJson((Map) obj));
            }
            else if (obj instanceof List) {
                jsonArray.add(toJson((List) obj));
            }
            else {
                jsonArray.add(obj);
            }
        }

        return jsonArray;
    }
	
	@SuppressWarnings("unchecked")
	public static JSONArray toOrgJson(List<Map<String, Object>> list) {
		JSONArray jsonArray = new JSONArray();
		
		for (Object obj : list) {
			if (obj instanceof Map) {
				jsonArray.put(toJson((Map) obj));
			}
			else if (obj instanceof List) {
				jsonArray.put(toJson((List) obj));
			}
			else {
				jsonArray.put(obj);
			}
		}
		
		return jsonArray;
	}
	
	@SuppressWarnings("unchecked")
	public static org.json.simple.JSONObject toJson(Map<String, Object> map) {
		org.json.simple.JSONObject jsonObject = new org.json.simple.JSONObject();

        for (String key : map.keySet()) {
            try {
                Object obj = map.get(key);
                if (obj instanceof Map) {
                    jsonObject.put(key, toJson((Map) obj));
                }
                else if (obj instanceof List) {
                    jsonObject.put(key, toJson((List) obj));
                }
                else {
                    jsonObject.put(key, map.get(key));
                }
            }
            catch (JSONException jsone) {
            	LOGGER.warn("RequestManager Failed to put value for " + key + " into JSONObject." +jsone);
            }
        }

        return jsonObject;
    }
	
	@SuppressWarnings("unchecked")
	public static JSONObject mapToOrgJson(Map<String, Object> map) {
		JSONObject jsonObject = new JSONObject();
		
		for (String key : map.keySet()) {
			try {
				Object obj = map.get(key);
				if (obj instanceof Map) {
					jsonObject.put(key, toJson((Map) obj));
				}
				else if (obj instanceof List) {
					jsonObject.put(key, toJson((List) obj));
				}
				else {
					jsonObject.put(key, map.get(key));
				}
			}
			catch (JSONException jsone) {
				LOGGER.warn("RequestManager Failed to put value for " + key + " into JSONObject." +jsone);
			}
		}
		
		return jsonObject;
	}
}
