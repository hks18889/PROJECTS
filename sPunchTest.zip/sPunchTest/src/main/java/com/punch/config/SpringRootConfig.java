package com.punch.config;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 *
 * @author Harendra Kumar Sah
 */
@Configuration
//@ComponentScan(basePackages = {"in.ezeon.capp.dao","in.ezeon.capp.service"})
@ComponentScan(basePackages = {"com.punch.dao","com.punch.service"})
public class SpringRootConfig {    
    //TODO: Services, DAO, DataSource, Email Sender or some other business layer beans   
	
	 @Bean
	    public BasicDataSource getDataSource(){
	    	System.out.println("getDataSource() ---");
	        BasicDataSource ds = new BasicDataSource();
	        ds.setDriverClassName("org.postgresql.Driver");
	        ds.setUrl("jdbc:postgresql://localhost:5432/contactdb");
	        ds.setUsername("postgres");
	        ds.setPassword("postgres");
	        ds.setMaxTotal(2);
	        ds.setInitialSize(1);
	        ds.setTestOnBorrow(true);
	        ds.setValidationQuery("SELECT 1");
	        ds.setDefaultAutoCommit(true);
	        return ds;
    }
	 
}
