/**
 * 
 */
package com.punch.dao.impl;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.google.gson.Gson;
import com.punch.bean.EmpFingerPrintPunching;
import com.punch.config.BaseDAO;
import com.punch.dao.EmpFingerPrintDao;


/**
 * @author Harendra Kumar Sah
 *
 */
@Repository
public class EmpFingerPrintDaoImpl extends BaseDAO implements EmpFingerPrintDao {
	private static final Logger LOGGER = LogManager.getLogger(EmpFingerPrintDaoImpl.class);
//	@Autowired
//	private JdbcTemplate jdbcTemplate;
	public EmpFingerPrintPunching empFingerPrintPunching(String hrmsEmployeeId) {
		// TODO Auto-generated method stub
		String sql="INSERT INTO settlement.employee_signature(\r\n" + 
				"hrms_employee_id,emp_thumb, emp_forefinger, emp_middlefinger, emp_ringfinger, emp_littlefinger, spouse_thumb, spouse_forefinger, spouse_middlefinger, spouse_ringfinger,\r\n" + 
				"spouse_littlefinger)\r\n" + 
				"VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
		return null;
	}

	public boolean saveFingerPrintSignature(String image, String finger) {
		// TODO Auto-generated method stub
		int hrmsid=1;
		 String anotherImage = image.substring(22);
		    byte[] b = anotherImage.getBytes();
		    //String userId=SecurityContextHolder.getContext().getAuthentication().getName().toString();
		    int rowCount=0;
		    String existsSql="SELECT 1 from contactdb.public.employee_signature WHERE hrms_employee_id=?";
		    //if(hrms id exists in DB) {
		    if(hrmsid==1) {
		    	String updateSql="update contactdb.public.employee_signature set "+finger+" = ? where hrms_employee_id = ?";
		    	System.out.println("updateSql :: "+updateSql);
		    	rowCount = getJdbcTemplate().update(updateSql, new Object[] {  b,"userId" } , new int[] { Types.BINARY,Types.VARCHAR   });
		    } else {
		    	
		    	String sql="INSERT into contactdb.public.employee_signature(hrms_employee_id, "+finger+") VALUES (?, ?)";
		    	rowCount = getJdbcTemplate().update(sql, new Object[] { "userId", b } , new int[] { Types.VARCHAR, Types.BINARY  });
		    }
		    
			System.out.println("rowCount :: "+rowCount);
			LOGGER.info("User: userId+, : saveSignature "+b+" "+rowCount+"   "+image);
			return rowCount>0?true:false;
		   
		
	}

	
	public String getFingerPrintSignature22(String hrmsId) {
		// TODO Auto-generated method stub
		
		byte[] fingerPrintImage=null;
		String signature=null;
		try {
//			String sqlFingerPrint="SELECT hrms_employee_id, emp_thumb, emp_forefinger, emp_middlefinger, emp_ringfinger, emp_littlefinger, spouse_thumb, spouse_forefinger,\r\n" + 
//					"spouse_middlefinger, spouse_ringfinger, spouse_littlefinger\r\n" + 
//					"FROM contactdb.public.employee_signature where hrms_employee_id=? ;";
			
			String sqlFingerPrint="SELECT  emp_thumb \r\n" +  
					" FROM contactdb.public.employee_signature where hrms_employee_id=? ;";
			System.out.println("sqlFingerPrint :: "+sqlFingerPrint);
			//image = jdbcTemplate146.queryForObject(this.environment.getProperty("SELECT_SIGNATURE"),
			fingerPrintImage = getJdbcTemplate().queryForObject(sqlFingerPrint, new Object[] {hrmsId}, new int[] { Types.VARCHAR}, byte[].class);
			signature=new String(fingerPrintImage);
			System.out.println("fingerPrintImage :: "+fingerPrintImage);
		} catch (Exception e) {
			LOGGER.error("User: "+hrmsId+", Exception --> "+e.getMessage());
		}
		return signature;
	}

	public Map<String, Object> getFingerPrintSignature(String hrmsId) {
		System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
		System.out.println(hrmsId);
		//String userId=SecurityContextHolder.getContext().getAuthentication().getName().toString();
		byte[] fingerPrintImage=null;
		Map<String, Object> result = null;
		String signature;
		String sqlFingerPrint="SELECT emp_thumb, emp_forefinger, emp_middlefinger, emp_ringfinger, emp_littlefinger, spouse_thumb, spouse_forefinger," + 
				  " spouse_middlefinger, spouse_ringfinger, spouse_littlefinger" + 
				  " FROM contactdb.public.employee_signature where hrms_employee_id=? ";
		
		try {
			//result=getJdbcTemplate().queryForMap(sqlFingerPrint,  new Object[] {hrmsId}, new int[] { Types.VARCHAR}, byte[].class);			
			result=getJdbcTemplate().queryForMap(sqlFingerPrint, new Object[] {hrmsId}, new int[] { Types.VARCHAR});	
			//signature=new String(fingerPrintImage);
			System.out.println(result);
		}catch (Exception e) {
			LOGGER.error("User: +userId+, GetFingerPrint --> "+hrmsId+", Exception --> "+e.getMessage());
			e.printStackTrace();
			}
		return result;
	}
	
	
	

}
