/**
 * 
 */
package com.punch.dao;

import java.util.Map;

import com.punch.bean.EmpFingerPrintPunching;

/**
 * @author Harendra Kumar Sah
 *
 */
public interface EmpFingerPrintDao {
	public EmpFingerPrintPunching empFingerPrintPunching(String hrmsEmployeeId);
	
	public boolean saveFingerPrintSignature(String image,String finger);
	
	public String getFingerPrintSignature22(String hrmsId);
	
	public Map<String, Object> getFingerPrintSignature(String hrmsId);

}
