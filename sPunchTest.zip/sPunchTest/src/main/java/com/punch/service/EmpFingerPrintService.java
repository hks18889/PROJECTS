/**
 * 
 */
package com.punch.service;

import java.util.Map;

import com.punch.bean.EmpFingerPrintPunching;

/**
 * @author Harendra Kumar Sah
 *
 */
public interface EmpFingerPrintService {
	public EmpFingerPrintPunching empFingerPrintPunching(String hrmsEmployeeId);
	
	public boolean saveFingerPrintSignature(String image,String finger);
	
	public String getFingerPrintSignature22(String hrmsId);
	
	public Map<String, String> getFingerPrintSignature(String hrmsId);
}
