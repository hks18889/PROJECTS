/**
 * 
 */
package com.punch.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.punch.bean.EmpFingerPrintPunching;
import com.punch.dao.EmpFingerPrintDao;
import com.punch.service.EmpFingerPrintService;


/**
 * @author Harendra Kumar Sah
 *
 */
@Service
public class EmpFingerPrintServiceImpl implements EmpFingerPrintService{
	@Autowired
	private EmpFingerPrintDao misReportsDAO;
	
	public EmpFingerPrintPunching empFingerPrintPunching(String hrmsEmployeeId) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean saveFingerPrintSignature(String image,String finger) {
		// TODO Auto-generated method stub
		return misReportsDAO.saveFingerPrintSignature(image,finger);
	}

	public String getFingerPrintSignature22(String hrmsId) {
		// TODO Auto-generated method stub
		return misReportsDAO.getFingerPrintSignature22(hrmsId);
	}

	public Map<String, String> getFingerPrintSignature(String hrmsId) {
		// TODO Auto-generated method stub
		Map<String, String> imageMap= new HashMap<String, String>();
		Map<String, Object> map=misReportsDAO.getFingerPrintSignature(hrmsId);
		for (String key: map.keySet()) {
			if(map.get(key)!=null) {
				byte[] imageByte=(byte[])map.get(key);
				imageMap.put(key, new String(imageByte));
			}
		}
		return imageMap;
	}
	
	
	
	

}
