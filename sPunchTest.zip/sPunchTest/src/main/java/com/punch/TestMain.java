/**
 * 
 */
package com.punch;

/**
 * @author Harendra Kumar Sah
 *
 */
public class TestMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("To check here for testing code");

	}

}
