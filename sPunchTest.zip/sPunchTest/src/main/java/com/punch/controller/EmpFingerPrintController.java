package com.punch.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.punch.controller.restController.EmpFingerPrintRestController;


/**
 * @author Harendra Kumar Sah
 *
 */
@Controller
public class EmpFingerPrintController {
	private static final Logger LOGGER = LogManager.getLogger(EmpFingerPrintController.class);
	
	@RequestMapping(value = {"/", "/index"})
    public String index(Model m) {  
		System.out.println("Welcome to punchController");
        return "index"; //JSP - /WEB-INF/view/index.jsp MFS100ClientServiceTest
    }
	
}
