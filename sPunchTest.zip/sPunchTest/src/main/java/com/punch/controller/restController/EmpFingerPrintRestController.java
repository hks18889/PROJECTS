/**
 * 
 */
package com.punch.controller.restController;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.punch.service.EmpFingerPrintService;




/**
 * @author Harendra Kumar Sah
 *
 */
@Controller
public class EmpFingerPrintRestController {
    private static final Logger LOGGER = LogManager.getLogger(EmpFingerPrintRestController.class);
	
    @Autowired
	private EmpFingerPrintService misReportsService;
//	@RequestMapping(value = "/finger-print-save", method=RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@RequestMapping(value = "/finger", method=RequestMethod.POST)
	public @ResponseBody ResponseEntity<String> fingerPrintSave(@RequestBody String request) {
		System.out.println(request);
		return new ResponseEntity<String>("Hello", HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/save-finger-print", method = RequestMethod.POST)
    public @ResponseBody ResponseEntity<String> saveSignature(@RequestParam (value="dataUrl") String dataUrl, @RequestParam String finger) {
		System.out.println("/save-finger-print RestController  ---> "+finger +" --  dataUrl :: "+dataUrl);
		Boolean result =false;
		String message;
		result=misReportsService.saveFingerPrintSignature(dataUrl,finger);
		if(result==true) {
			message= "Finger Print Impression is  successfully saved for employeee with HRMS ID ";
		 }else{
	            message= "Finger Print Impression is failed for employeee with HRMS ID  ";
	        }
		org.json.JSONObject jsonObject = new org.json.JSONObject();
		jsonObject.put("result", result);
		jsonObject.put("message", message);
		System.out.print("result :: "+result);
		return new ResponseEntity<String>(jsonObject.toString(), HttpStatus.OK) ;
	}
	
	@RequestMapping(value = "/get-finger-print-doc22", method = RequestMethod.POST)
    public String getFingerPrintDoc(@RequestParam (value="hrmsId")String hrmsId, HttpServletResponse response, Model model) {
    	response.setStatus(200);
    	System.out.println("get-finger-print-doc :: "+hrmsId);
    	String fingerPrintImage=misReportsService.getFingerPrintSignature22(hrmsId);
    	System.out.println("fingerPrintImage : "+fingerPrintImage);
    	if(fingerPrintImage!=null) {model.addAttribute("fingerPrintImage", fingerPrintImage);}
    	return "finger-print-doc";
	}
	
	@RequestMapping(value = "/get-finger-print-doc", method = RequestMethod.POST)
	 public  String   getEmpTransferDetails(@RequestParam (value="hrmsId")String hrmsId, HttpServletResponse response, Model model) {
		 response.setStatus(200);
		 System.out.println(hrmsId);
		 Map<String, String> map =  misReportsService.getFingerPrintSignature(hrmsId);
		 LOGGER.info(map);
		 System.out.println(map);
		 if (map != null) { 
			 	model.addAttribute("fingerPrintImage", map); 
			 }
		 return "finger-print-doc"; 
		//return new Gson().toJson(map); 
		
	 }

}
