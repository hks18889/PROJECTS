/**
 * 
 */
package com.punch.bean;

/**
 * @author Harendra Kumar Sah
 *
 */
public class FingerPrintRequest {

	private String finger;
	private String data;
	public String getFinger() {
		return finger;
	}
	public void setFinger(String finger) {
		this.finger = finger;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	
}
