/**
 * 
 */
package com.punch.bean;

/**
 * @author Harendra Kumar Sah
 *
 */
public class EmpFingerPrintPunching {
	 private String hrms_employee_id;
	 private String emp_thumb;
	 private String emp_forefinger;
	 private String emp_middlefinger; 
	 private String emp_ringfinger; 
	 private String emp_littlefinger;
	 private String spouse_thumb;
	 private String spouse_forefinger;
	 private String spouse_middlefinger;
	 private String spouse_ringfinger;
	 private String spouse_littlefinger;
	public String getHrms_employee_id() {
		return hrms_employee_id;
	}
	public void setHrms_employee_id(String hrms_employee_id) {
		this.hrms_employee_id = hrms_employee_id;
	}
	public String getEmp_thumb() {
		return emp_thumb;
	}
	public void setEmp_thumb(String emp_thumb) {
		this.emp_thumb = emp_thumb;
	}
	public String getEmp_forefinger() {
		return emp_forefinger;
	}
	public void setEmp_forefinger(String emp_forefinger) {
		this.emp_forefinger = emp_forefinger;
	}
	public String getEmp_middlefinger() {
		return emp_middlefinger;
	}
	public void setEmp_middlefinger(String emp_middlefinger) {
		this.emp_middlefinger = emp_middlefinger;
	}
	public String getEmp_ringfinger() {
		return emp_ringfinger;
	}
	public void setEmp_ringfinger(String emp_ringfinger) {
		this.emp_ringfinger = emp_ringfinger;
	}
	public String getEmp_littlefinger() {
		return emp_littlefinger;
	}
	public void setEmp_littlefinger(String emp_littlefinger) {
		this.emp_littlefinger = emp_littlefinger;
	}
	public String getSpouse_thumb() {
		return spouse_thumb;
	}
	public void setSpouse_thumb(String spouse_thumb) {
		this.spouse_thumb = spouse_thumb;
	}
	public String getSpouse_forefinger() {
		return spouse_forefinger;
	}
	public void setSpouse_forefinger(String spouse_forefinger) {
		this.spouse_forefinger = spouse_forefinger;
	}
	public String getSpouse_middlefinger() {
		return spouse_middlefinger;
	}
	public void setSpouse_middlefinger(String spouse_middlefinger) {
		this.spouse_middlefinger = spouse_middlefinger;
	}
	public String getSpouse_ringfinger() {
		return spouse_ringfinger;
	}
	public void setSpouse_ringfinger(String spouse_ringfinger) {
		this.spouse_ringfinger = spouse_ringfinger;
	}
	public String getSpouse_littlefinger() {
		return spouse_littlefinger;
	}
	public void setSpouse_littlefinger(String spouse_littlefinger) {
		this.spouse_littlefinger = spouse_littlefinger;
	}

}
