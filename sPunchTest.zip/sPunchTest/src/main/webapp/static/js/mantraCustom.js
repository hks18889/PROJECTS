 var quality = 60; //(1 to 100) (recommanded minimum 55)
        var timeout = 10; // seconds (minimum=10(recommanded), maximum=60, unlimited=0 )

        function GetInfo() {
            document.getElementById('tdSerial').innerHTML = "";
            document.getElementById('tdCertification').innerHTML = "";
            document.getElementById('tdMake').innerHTML = "";
            document.getElementById('tdModel').innerHTML = "";
            document.getElementById('tdWidth').innerHTML = "";
            document.getElementById('tdHeight').innerHTML = "";
            document.getElementById('tdLocalMac').innerHTML = "";
            document.getElementById('tdLocalIP').innerHTML = "";
            document.getElementById('tdSystemID').innerHTML = "";
            document.getElementById('tdPublicIP').innerHTML = "";


            var key = document.getElementById('txtKey').value;

            var res;
            if (key.length == 0) {
                res = GetMFS100Info();
            }
            else {
                res = GetMFS100KeyInfo(key);
            }

            if (res.httpStaus) {

                document.getElementById('txtStatus').value = "ErrorCode: " + res.data.ErrorCode + " ErrorDescription: " + res.data.ErrorDescription;

                if (res.data.ErrorCode == "0") {
                    document.getElementById('tdSerial').innerHTML = res.data.DeviceInfo.SerialNo;
                    document.getElementById('tdCertification').innerHTML = res.data.DeviceInfo.Certificate;
                    document.getElementById('tdMake').innerHTML = res.data.DeviceInfo.Make;
                    document.getElementById('tdModel').innerHTML = res.data.DeviceInfo.Model;
                    document.getElementById('tdWidth').innerHTML = res.data.DeviceInfo.Width;
                    document.getElementById('tdHeight').innerHTML = res.data.DeviceInfo.Height;
                    document.getElementById('tdLocalMac').innerHTML = res.data.DeviceInfo.LocalMac;
                    document.getElementById('tdLocalIP').innerHTML = res.data.DeviceInfo.LocalIP;
                    document.getElementById('tdSystemID').innerHTML = res.data.DeviceInfo.SystemID;
                    document.getElementById('tdPublicIP').innerHTML = res.data.DeviceInfo.PublicIP;
                }
            }
            else {
                alert(res.err);
            }
            return false;
        }

        function Capture() {
            try {
                document.getElementById('txtStatus').value = "";
                document.getElementById('imgFinger').src = "data:image/bmp;base64,";
                //document.getElementById('txtImageInfo').value = "";
                //document.getElementById('txtIsoTemplate').value = "";
                //document.getElementById('txtAnsiTemplate').value = "";
                //document.getElementById('txtIsoImage').value = "";
                //document.getElementById('txtRawData').value = "";
                //document.getElementById('txtWsqData').value = "";

                var res = CaptureFinger(quality, timeout);
                if (res.httpStaus) {

                    document.getElementById('txtStatus').value = "ErrorCode: " + res.data.ErrorCode + " ErrorDescription: " + res.data.ErrorDescription;

                    if (res.data.ErrorCode == "0") {
                        document.getElementById('imgFinger').src = "data:image/bmp;base64," + res.data.BitmapData;
                        var imageinfo = "Quality: " + res.data.Quality + " Nfiq: " + res.data.Nfiq + " W(in): " + res.data.InWidth + " H(in): " + res.data.InHeight + " area(in): " + res.data.InArea + " Resolution: " + res.data.Resolution + " GrayScale: " + res.data.GrayScale + " Bpp: " + res.data.Bpp + " WSQCompressRatio: " + res.data.WSQCompressRatio + " WSQInfo: " + res.data.WSQInfo;
                        //document.getElementById('txtImageInfo').value = imageinfo;
                        //document.getElementById('txtIsoTemplate').value = res.data.IsoTemplate;
                        //document.getElementById('txtAnsiTemplate').value = res.data.AnsiTemplate;
                       // document.getElementById('txtIsoImage').value = res.data.IsoImage;
                        //document.getElementById('txtRawData').value = res.data.RawData;
                        //document.getElementById('txtWsqData').value = res.data.WsqImage;
						document.getElementById('testData').value ="data:image/bmp;base64," + res.data.BitmapData;

                    }
                    
                }
                else {
                    alert(res.err);
                }
            }
            catch (e) {
                alert(e);
            }
            return false;
        }
        
        function CaptureSpouse() {
            try {
                document.getElementById('txtStatus').value = "";
                document.getElementById('imgFingerSpouse').src = "data:image/bmp;base64,";
                //document.getElementById('txtImageInfo').value = "";
                //document.getElementById('txtIsoTemplate').value = "";
                //document.getElementById('txtAnsiTemplate').value = "";
                //document.getElementById('txtIsoImage').value = "";
                //document.getElementById('txtRawData').value = "";
                //document.getElementById('txtWsqData').value = "";

                var res = CaptureFinger(quality, timeout);
                if (res.httpStaus) {

                    document.getElementById('txtStatus').value = "ErrorCode: " + res.data.ErrorCode + " ErrorDescription: " + res.data.ErrorDescription;

                    if (res.data.ErrorCode == "0") {
                        document.getElementById('imgFingerSpouse').src = "data:image/bmp;base64," + res.data.BitmapData;
                        var imageinfo = "Quality: " + res.data.Quality + " Nfiq: " + res.data.Nfiq + " W(in): " + res.data.InWidth + " H(in): " + res.data.InHeight + " area(in): " + res.data.InArea + " Resolution: " + res.data.Resolution + " GrayScale: " + res.data.GrayScale + " Bpp: " + res.data.Bpp + " WSQCompressRatio: " + res.data.WSQCompressRatio + " WSQInfo: " + res.data.WSQInfo;
                        //document.getElementById('txtImageInfo').value = imageinfo;
                        //document.getElementById('txtIsoTemplate').value = res.data.IsoTemplate;
                        //document.getElementById('txtAnsiTemplate').value = res.data.AnsiTemplate;
                       // document.getElementById('txtIsoImage').value = res.data.IsoImage;
                        //document.getElementById('txtRawData').value = res.data.RawData;
                        //document.getElementById('txtWsqData').value = res.data.WsqImage;
						document.getElementById('testData').value ="data:image/bmp;base64," + res.data.BitmapData;

                    }
                }
                else {
                    alert(res.err);
                }
            }
            catch (e) {
                alert(e);
            }
            return false;
        }

      
 /*  -----   try to save data ------------ */
 
 /* test saving data to database  */

 
 function SaveOnClick(finger) {
	 
	// alert(document.getElementById('testData').value);
	var imageData=document.getElementById('testData').value;
	console.log("finger selected:"+$("#empFinger").val());
	 $.ajax({
		 type: 'POST',
         url:getContextPath() + '/save-finger-print',
         data:{dataUrl: imageData, finger: finger } ,
         success: function (resultData) {  
             ///alert("datalll ::"+resultData);
             console.log('resultData :: '+resultData);
             console.log("Saved Finger Print Impression"); 
             
             
         }
     });
    }
 
 
 //fingerPrint View start
 
 $(document).on("click", '#finger-print-doc', function(e) {
	 var imageData2=document.getElementById('testData').value;
	 console.log("sssssssssssssssssssssssssssssssssssssssssssssssssssss");
	 console.log($("#empFinger").val());
			$.ajax({
				
				url: getContextPath() + "/get-finger-print-doc",
		      	type: "POST",
		      	//data: {hrmsId: "userId"}, //working
		      	data: {hrmsId: $("#hrms_employee_id").val()}, 
		      	success: function(response) {
		      		console.log("response :: "+response);
		      		$("#finger-print-doc-div").html(response);
		      		var divToPrint=document.getElementById("print-content");
		      	   	newWin= window.open("");
		      	   	newWin.document.write($("#finger-print-doc-div").html());
		      	   	/* newWin.print();
		      	   	newWin.close(); */
		      	  	var is_chrome = Boolean(newWin.chrome);
			          newWin.document.close(); // necessary for IE >= 10 and necessary before onload for chrome
	
			          if (is_chrome) {
			              newWin.onload = function() { // wait until all resources loaded 
			                  newWin.focus(); // necessary for IE >= 10
			                  newWin.print();  // change window to newWin
			                  newWin.close();// change window to newWin
			              };
			          }
			          else {
			              newWin.document.close(); // necessary for IE >= 10
			              newWin.focus(); // necessary for IE >= 10
			              newWin.print();
			              newWin.close();
			          }
		      		
		      	}
			});
		});