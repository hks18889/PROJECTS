/**
 * 
 */
$(function(){
    jQuery('img.svg').each(function(){
        var $img = jQuery(this);
        var imgID = $img.attr('id');
        var imgClass = $img.attr('class');
        var imgURL = $img.attr('src');
    
        jQuery.get(imgURL, function(data) {
            // Get the SVG tag, ignore the rest
            var $svg = jQuery(data).find('svg');
    
            // Add replaced image's ID to the new SVG
            if(typeof imgID !== 'undefined') {
                $svg = $svg.attr('id', imgID);
            }
            // Add replaced image's classes to the new SVG
            if(typeof imgClass !== 'undefined') {
                $svg = $svg.attr('class', imgClass+' replaced-svg');
            }
    
            // Remove any invalid XML tags as per http://validator.w3.org
            $svg = $svg.removeAttr('xmlns:a');
            
            // Check if the viewport is set, else we gonna set it if we can.
            if(!$svg.attr('viewBox') && $svg.attr('height') && $svg.attr('width')) {
                $svg.attr('viewBox', '0 0 ' + $svg.attr('height') + ' ' + $svg.attr('width'))
            }
    
            // Replace image with new SVG
            $img.replaceWith($svg);
    
        }, 'xml');
    
    });
});

var specialKeys = new Array();
specialKeys.push(8); // Backspace
function IsNumeric(e) {
    var keyCode = e.which ? e.which : e.keyCode
    var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
// https://www.journaldev.com/2597/spring-datasource-jndi-with-tomcat-example
    /*
	 * var id=$(e).attr('id'); console.log("id : "+id);
	 */
// $("#"+id).val() == ret ? $("#"+id).hide() : $("#"+id).show();
// $("#"+id).val() == ret ? $("#"+id).hide() : $("#"+id).show();
// $("#"+id+"-error").css("display") = ret ? "none" : "block";
// document.getElementById("personalMobileNumber-error").style.display = ret ?
// "none" : "inline";
    return ret;
}

function getContextPath() {
    return window.location.pathname.substring(0, window.location.pathname.indexOf("/",2));
}

$('input').keyup(function() {
    if(($(this).parent()).find(".server-errors").length > 0) {
        $(".server-errors",$(this).parent()).remove();
    }
});
$('select').keyup(function() {
    if(($(this).parent()).find(".server-errors").length > 0) {
        $(".server-errors",$(this).parent()).remove();
    }
});

function scrollToTopAppBody() {
    $('.app-body').loading();
    $(".app-body").animate({ scrollTop: 0 }, "fast", function(){
        $(".app-body").off("scroll mousedown wheel DOMMouseScroll mousewheel keyup touchmove");
    });
    setInterval(function () {
        $(':loading').loading('stop');
    }, 1000);
}

setTimeout(function() {
    $('.alert-success, .alert-danger').fadeOut('slow');
}, 10000);


/*******************************************************************************
 * auto input character case(Upper,Lower,Normal) selection case from properties
 * file according to key.
 * 
 * @author Bhagvan Singh Jadoun begin....
 ******************************************************************************/


function caseConversionForId(columnName) {
	columnName = columnName.toLowerCase().replace(/\b[a-z]/g, function(letter) {
	    return letter.toUpperCase();
	});
}

function inputValueCaseChange(obj) {
    var id=$(obj).attr('id');
    var optionVal=$("#"+id+"-opt").val();
// console.log("optionVal : "+optionVal);
    if(optionVal=="U") {
        $("#"+id).val($("#"+id).val().toUpperCase());
    } else  if(optionVal=="L") {
        $("#"+id).val($("#"+id).val().toLowerCase());
    }
    else {
        $("#"+id).val($("#"+id).val());
    }
}

function inputValueCaseChangeV2(optionVal, value) {
	if (optionVal == "U") {
		return value.toUpperCase();
	} else if (optionVal == "L") {
		return value.toLowerCase();
	} else {
		return value;
	}
}

/*******************************************************************************
 * auto input character case(Upper,Lower,Normal) selection case from properties
 * file according to key. end....
 ******************************************************************************/


/**
 * set Master data on drop down
 * 
 * @author Bhagvan Singh Jadoun begin....
 */
function setMasterDataValue(optionListObj,jsonArray) {
    var optionData="";
    $(optionListObj).empty().append('<option selected="selected" value="">Please select</option>');
    if(jsonArray != null) {
    	jsonArray.forEach(function(optionDataResult) {
            optionData +="<option value=" + optionDataResult.code + ">" + optionDataResult.description + "</option>";
        });
        optionListObj.append(optionData);
    }
}


function setMasterDataValueForBirthday(optionListObj,jsonArray) {
	var optionData="";
	$(optionListObj).empty().append('<option selected="selected" value="">Please select</option>');
	if(jsonArray != null) {
		jsonArray.forEach(function(optionDataResult) {
			optionData +="<option value=" + optionDataResult.code + ">" + optionDataResult.description + "</option>";
			// $(optionListObj).empty().append('<option selected="selected"
			// value="">Please select</option>');
			// optionListObj.push(optionData);
		});
		optionListObj.append(optionData);
	}
	
	/*
	 * else { $(optionListObj).empty().append('<option selected="selected"
	 * value="">Please select</option>'); }
	 */
}

function setMasterDataValueForCountry(optionListObj,jsonArray) {
    var optionData="";
    if(jsonArray != null) {
    	jsonArray.forEach(function(optionDataResult) {
    		if(optionDataResult.description=='INDIA') {
    			optionData +="<option value=" + optionDataResult.code +"selected='selected'"+">" + optionDataResult.description + "</option>";
    		}
    		else {
    			optionData +="<option value=" + optionDataResult.code + ">" + optionDataResult.description + "</option>";
    		}
            
        });
        optionListObj.append(optionData);
    }
    else {
    	$(optionListObj).empty().append('<option selected="selected" value="">Please select</option>');
    }
}

// end...

/**
 * Format a date like YYYY-MM-DD.
 * 
 * @param {string}
 *            template
 * @param {Date=}
 *            [date]
 * @return {string}
 * @author Bhagvan Singh Jadoun begin....
 */
function formatDate(date) {
	var dateParts = date.split("/");
	return dateParts[2]+"-"+dateParts[1] - 1+"-"+ dateParts[0];
}

function formatDate(template, date) {
    var date1 = new Date(date);
	/*
	 * var dateParts = dateString.split("/"); var dateObject = new
	 * Date(dateParts[2], dateParts[1] - 1, dateParts[0]);
	 */
    var specs = 'YYYY:MM:DD:HH:mm:ss'.split(':');
    date = new Date(date || Date.now() - new Date().getTimezoneOffset() * 6e4);
    return date.toISOString().split(/[-:.TZ]/).reduce(function(template, item, i) {
        return template.split(specs[i]).join(item);
    }, template);
}


function mobileNumberValidation(inputTxt)
{
	var id=$(inputTxt).attr('id');
    var optionVal=$("#"+id).val();
	if(isNumberKey(inputTxt)) {
// var phoneNo = /^\+?([7-9]{2})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{4})$/;
		var phoneNo = /^([6-9]{1})([0-9]{9})$/;
		   if((inputTxt.value.match(phoneNo)))
		     {
// $("#"+id).val(optionVal);
		      return inputTxt;
		     }
		     else { 
		        return false;
		    }
	}
  
}

// end...


/*
 * $("#officialMobileNo").keypress(function(event) { var phone =
 * $("#officialMobileNo").val(); var pattern =
 * /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/; var pattern1 =
 * /^[7-9]\d{0}$/; if(pattern1.test(phone)) { if(pattern1.test(phone)) {
 * alert(pattern.test(phone)); return true; } } else { return false; }
 * 
 * });
 */

/*******************************************************************************
 * for keyup only allow number only
 * 
 * @param evt
 * @returns {boolean}
 */
function isNumberKey(evt)
{
	/*
	 * console.log("evt.charAt(0) : "+evt.charAt(0)); var charCode = (evt.which) ?
	 * evt.which : event.keyCode; var charCode = (evt.which) ? evt.which :
	 * event.keyCode; if (!(charCode > 31 && (charCode < 48 || charCode > 57)) ) {
	 * console.log("if.... : "+evt.charAt(0)); if (!(evt.charAt(0)=="9" &&
	 * evt.charAt(0)=="8" && evt.charAt(0)=="7") ) { return false; } else {
	 * return true; } return true; } return false;
	 */
	/*
	 * var charCode = (evt.which) ? evt.which : event.keyCode; if (charCode > 31 &&
	 * (charCode < 48 || charCode > 57)) return false; return true;
	 */
	
	var e = evt || window.event; // window.event is safer, thanks
	// @ThiefMaster
	var charCode = e.which || e.keyCode;

	if (charCode > 31 && (charCode < 47 || charCode > 57) && (charCode != 46))
		return false;
	if (e.shiftKey)
		return false;
	if (charCode == 47)
		return false;
	return true;
}

/*******************************************************************************
 * for keyup only allow character only
 * 
 * @param evt
 * @returns {boolean}
 */
$(document).on("keypress", ".txtOnly", function(e) {
// $( ".txtOnly" ).keypress(function(e) {
    var key = e.keyCode;
// if ((!(key >= 97 && key <= 122)) || key == 190) {
    	 if (!((key >= 65 && key <= 90) || (key >= 97 && key <= 122) || key == 32 || key == 46)) {
        e.preventDefault();
    }
});

$(document).on("keypress", ".txtNumOnly", function(e) {
// $( ".txtNumOnly" ).keypress(function(e) {
    var key = e.keyCode;
// if ((!(key >= 97 && key <= 122)) || key == 190) {
    	 if (!((48 <= key && key <= 57) || ( key >= 65 && key <=90) || ( key >= 97 && key <=122) || key == 32)) {
        e.preventDefault();
    }
});

/**
 * Function to replace < & > signs by html supported tags 
 * @param e
 * @returns
 */
$(document).on("change", "textarea, input[type=text]", function(e) {
		$(this).val($(this).val().replace("<", "&lt;").replace(">", "&gt;"));
	});


/*
 * $( ".txtOnly" ).keypress(function(evt) { var theEvent = evt || window.event;
 * var key = theEvent.keyCode || theEvent.which; key = String.fromCharCode(key);
 * var key=evt.data.value; var regex = /^[a-zA-Z0-9\b\t]*$/; // @Bhagvan Singh
 * Jadoun console.log(); if (!regex.test(key)) { theEvent.returnValue = false; //
 * if (theEvent.preventDefault) theEvent.preventDefault(); } }
 */

/*
 * function validatePersoneName(name) { console.log(); var filter =
 * /^[a-zA-Z][a-zA-Z0-9-\b ]*$/; return filter.test(name); }
 */


/**
 * date validation
 */
function isDate()
{
	
    var currVal = $("#dateOfBirth").val();
    if(currVal == '') {
    	return false;
    }
    
    var rxDatePattern = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/; // Declare
																	// Regex
    var dtArray = currVal.match(rxDatePattern); // is format OK?
    console.log(dtArray);
    console.log(currVal);
    if (dtArray == null) {
    	return false;
    }
        
    // Checks for mm/dd/yyyy format.
    dtMonth = dtArray[3];
    dtDay= dtArray[1];
    dtYear = dtArray[5];        
    
    if (dtMonth < 1 || dtMonth > 12) {
    	return false;
    }
        
    else if (dtDay < 1 || dtDay> 31) {
    	return false;
    }
        
    else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31) {
    	 return false;
    }
       
    else if (dtMonth == 2) 
    {
        var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
        if (dtDay> 29 || (dtDay ==29 && !isleap)) 
                return false;
    }
    return true;
}


function isValidDate(date)
{
    var matches = /^(\d{2})[-\/](\d{2})[-\/](\d{4})$/.exec(date);
    if (matches == null) {
      var matches = /^(\d{4})[-\/](\d{2})[-\/](\d{2})$/.exec(date);
      if (matches == null) {
        return false;
      }
    }
    var d = matches[2];
    var m = matches[1] - 1;
    var y = matches[3];
    var composedDate = new Date(y, m, d);
    return composedDate.getDate() == d &&
            composedDate.getMonth() == m &&
            composedDate.getFullYear() == y;
}


function adharNoValidation() {
	var adhar=$("#aadhaarNumber").val();
	console.log("adhar ==> "+adhar);
	var filter = /^(?!0+$)[0-9]{1,12}$/;
	console.log("filter.test(adhar) : "+filter.test(adhar));
	if(!filter.test(adhar)) {
		$("#aadhaarNumber").focus();
		return false;
	}
	
}



function validateEmailAddress(email) {
	var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	return filter.test(email);
}

function isValidNumberValue(evt) {
	var e = evt || window.event; // window.event is safer, thanks
	// @ThiefMaster
	var charCode = e.which || e.keyCode;

	if (charCode > 31 && (charCode < 47 || charCode > 57) && (charCode != 46))
		return false;
	if (e.shiftKey)
		return false;
	if (charCode == 47)
		return false;
	return true;
}

function isValidStringValueOnly(evt) {
	var theEvent = evt || window.event;
	var key = theEvent.keyCode || theEvent.which;
	key = String.fromCharCode(key);
	var regex = /^[a-zA-Z0-9-\b\t ]*$/; // @Bhagvan
	if (!regex.test(key)) {
		theEvent.returnValue = false;
		if (theEvent.preventDefault)
			theEvent.preventDefault();
	}
}
function isValidAlphaNumericValueOnly(evt) {
	var theEvent = evt || window.event;
	var key = theEvent.keyCode || theEvent.which;
	key = String.fromCharCode(key);
	var regex = /^[a-zA-Z0-9\b\t]*$/; // @Bhagvan
	if (!regex.test(key)) {
		theEvent.returnValue = false;
		if (theEvent.preventDefault)
			theEvent.preventDefault();
	}
}

function validateName(name) {
	var filter = /^[a-zA-Z][a-zA-Z0-9-\b ]*$/; // @Bhagvan
	return filter.test(name);
}

function validateNumberOnly(mobile) {
	var filter = /^[0-9\.\,]*$/; // @Bhagvan
	return filter.test(mobile);
}

/*
 * created by Bhagvan Singh on 22-11-2018 For focus on validated text field
 * start
 */
function focusForValidation(id) {
	$("#" + id).css("border", "1px solid red");
	$("#" + id).click(function() {
		$(this).css("border", "1px solid #cccccc");
	});
}

(function() {
	'use strict';
	window.addEventListener('load', function() {
	// Fetch all the forms we want to apply custom Bootstrap validation styles
	// to
	var forms = document.getElementsByClassName('needs-validation');
	// Loop over them and prevent submission
	var validation = Array.prototype.filter.call(forms, function(form) {
	form.addEventListener('submit', function(event) {
		event.preventDefault();
	if (form.checkValidity() === false) {	
		event.stopPropagation();
	}
	form.classList.add('was-validated');
	}, false);
	});
	}, false);
	})();


function getEmployeeMasterDataForBirthday() {
// console.log("getEmployeeMasterData()-->");
// var employeeId = 1234;
  var ajax = $.ajax({
      type: 'GET',
      // data: {employeeId: employeeId},
      url: getContextPath()+'/ajax/birthday-list/get-railway-unit-data',
// url: "<c:url value="/emp-master/get-master-data" />",
      success: function (resultData) {
          var railwayUnitList = $('#railwayUnitDescription');
          console.log("railwayUnitList"+railwayUnitList);
          var railwayUnitJsonResult = JSON.parse(resultData.railwayUnitJsonObject);
          if (railwayUnitJsonResult != null) {
              var railwayUnitJsonArray = railwayUnitJsonResult.unitdescription;
              setMasterDataValueForBirthday(railwayUnitList,railwayUnitJsonArray);
          }
          else {
              console.log("clear form Gender fields.");
          }
          
      }
  });
}

function getRailwayNameByUnitFlag(unitFlag) {
    console.log("unitFlag : "+unitFlag);
    if(unitFlag != "" && unitFlag!=null) {
    	var ajax = $.ajax({
            type: 'POST',
            data:{unitFlag: unitFlag},
            url: getContextPath()+'/ajax/birthday-list/getRailwayNameByUnitFlag',
            success: function(resultData) {
                var RailwayNameOptionList = $('#railwayUnitName');
                var RailwayNameJsonResult = JSON.parse(resultData.railwayname);
                if (RailwayNameJsonResult != null) {
                    var RailwayNameJsonArray = RailwayNameJsonResult.railwayunitname;
                    setMasterDataValue(RailwayNameOptionList,RailwayNameJsonArray);
                }
                else {
                    console.log("clear form divisions Options Data fields .");
                    alertify.error("unitFlag doesn't have any railway Name.");
                }
            }
        });
    }
    else {
    	$('#railwayUnitName').empty().append('<option selected="selected" value="">Please select</option>');
    }
}




/* end */
var timeOut;
var showPreExpiredMsg;
var sessionTimeOut;
$(document).ready(function(){
	if ($('#exampleModal-danger-header').length) {
		timeOut = $('meta[name=_timeout]').attr("content");
		if (!(typeof timeOut === "undefined") && timeOut != null && timeOut != "" && !Number.isNaN(timeOut)) {
			showPreExpiredMsg = window.setTimeout(function() {
				console.log("Your session will be expired in next "+ (timeOut*20/100) +" seconds.");
				$('#exampleModal-danger-header .modal-dialog .modal-content .modal-body p').html("Your session will be expired in next <span id='timerCountdown'>"+ (timeOut*20/100) +"</span> seconds.");
				var timeleft=(timeOut*20/100);
				var downloadTimer = setInterval(function(){
			    timeleft--;
			    document.getElementById("timerCountdown").textContent = timeleft;
			    if(timeleft <= 0)
			        clearInterval(downloadTimer);
			    },1000);
				$('#exampleModal-danger-header').modal('show');
			},((timeOut-(timeOut*20/100))* 1000));
			sessionTimeOut = window.setTimeout(function() {
				$('#exampleModal-danger-header').modal('hide');
			 	location.reload();
			},((timeOut+5)* 1000));
			$("#continue-session").click(function() {
				$.ajax({
					type: "GET",
					url: getContextPath() + "/ajax/validate-session",
					success: function (json) {
						console.log(json);
						if (json.status == 'ok') {
							window.clearTimeout(showPreExpiredMsg);
							window.clearTimeout(sessionTimeOut);
							showPreExpiredMsg = window.setTimeout(function() {
								// console.log("Your session will be expired in
								// next "+ (timeOut*20/100) +" seconds.");
								$('#exampleModal-danger-header .modal-dialog .modal-content .modal-body p').html("Your session will be expired in next <span id='timerCountdown'>"+ (timeOut*20/100) +"</span> seconds.");
								var timeleft=(timeOut*20/100);
								var downloadTimer = setInterval(function(){
							    timeleft--;
							    document.getElementById("timerCountdown").textContent = timeleft;
							    if(timeleft <= 0)
							        clearInterval(downloadTimer);
							    },1000);
								$('#exampleModal-danger-header').modal('show');
							},((timeOut-(timeOut*20/100))* 1000));
							sessionTimeOut = window.setTimeout(function() {
								$('#exampleModal-danger-header').modal('hide');
								// console.log("Your session is expired.");
						     	location.reload();
							},((timeOut+5)* 1000));
						}
						$('#exampleModal-danger-header').modal('toggle');
					}, error: function(xhr, ajaxOptions, thrownError) {
						console.log("Something went wrong.")
					}
				});
			});
		}
	}
	if($("#loginForm").length){
		$('#loginForm').bootstrapValidator({
	        feedbackIcons: {
	            valid: 'glyphicon glyphicon-ok',
	            invalid: 'glyphicon glyphicon-remove',
	            validating: 'glyphicon glyphicon-refresh'
	        },
	        fields: {
	        	username: {
	                validators: {
	                    notEmpty: {
	                        message: 'The username is required'
	                    }
	                }
	            },
	            emailAddress: {
	            	validators: {
	            		callback: {
	            			message: 'Invalid Email ID',
	            			callback: function(value, validator, $field) {
	            				if($('#username').val()=='----') {
	            					return false;
	            				}
	            				else return true;
	            			}
	            		}
	            	}
	            },
	            password: {
	                validators: {
	                    notEmpty: {
	                        message: 'The password is required'
	                    }
	                }
	            }
	        }
	    });
	}
	
	if($("#otp_form").length){
		$('#otp_form').bootstrapValidator({
	        feedbackIcons: {
	            valid: 'glyphicon glyphicon-ok',
	            invalid: 'glyphicon glyphicon-remove',
	            validating: 'glyphicon glyphicon-refresh'
	        },
	        fields: {
	        	otp: {
	                validators: {
	                    notEmpty: {
	                        message: 'The otp is required'
	                    },
	                    integer: {
                        	message: "OTP should have integer only."
                        },
                        stringLength: {
                            max: 5,
                            min: 5,
                            message: 'The OTP must have 5 characters'
                        }
	                }
	            }
	        }
	    });
	}
	
	if($('.switch-role-a').length>0){
		$('.switch-role-a').click(function(event){
			event.preventDefault();
			$('#switchRoleForm').attr('action', $(this).attr('href'));
			$('#switchRoleForm')[0].submit();
		});
	}
	
	
	
});

var timeOut;
var showPreExpiredMsg;
var sessionTimeOut;
$(document).ready(function(){
	timeOut = $('meta[name=_timeout]').attr("content");
	if (!(typeof timeOut === "undefined") && timeOut != null && timeOut != "" && !Number.isNaN(timeOut)) {
		console.log(timeOut);
		showPreExpiredMsg = window.setTimeout(function() {
			console.log("Your session will be expired in next "+ (timeOut*20/100) +" seconds.");
			$('#exampleModal-danger-header .modal-dialog .modal-content .modal-body p').html("Your session will be expired in next <span id='timerCountdown'>"+ (timeOut*20/100) +"</span> seconds.");
			var timeleft=(timeOut*20/100);
			var downloadTimer = setInterval(function(){
		    timeleft--;
		    document.getElementById("timerCountdown").textContent = timeleft;
		    if(timeleft <= 0)
		        clearInterval(downloadTimer);
		    },1000);
			$('#exampleModal-danger-header').modal('show');
		},((timeOut-(timeOut*20/100))* 1000));
		sessionTimeOut = window.setTimeout(function() {
			$('#exampleModal-danger-header').modal('hide');
		 	location.reload();
		},((timeOut+5)* 1000));
		$("#continue-session").click(function() {
			$.ajax({
				type: "GET",
				url: getContextPath() + "/ajax/validate-session",
				success: function (json) {
					console.log(json);
					if (json.status == 'ok') {
						window.clearTimeout(showPreExpiredMsg);
						window.clearTimeout(sessionTimeOut);
						showPreExpiredMsg = window.setTimeout(function() {
							// console.log("Your session will be expired in next
							// "+ (timeOut*20/100) +" seconds.");
							$('#exampleModal-danger-header .modal-dialog .modal-content .modal-body p').html("Your session will be expired in next <span id='timerCountdown'>"+ (timeOut*20/100) +"</span> seconds.");
							var timeleft=(timeOut*20/100);
							var downloadTimer = setInterval(function(){
						    timeleft--;
						    document.getElementById("timerCountdown").textContent = timeleft;
						    if(timeleft <= 0)
						        clearInterval(downloadTimer);
						    },1000);
							$('#exampleModal-danger-header').modal('show');
						},((timeOut-(timeOut*20/100))* 1000));
						sessionTimeOut = window.setTimeout(function() {
							$('#exampleModal-danger-header').modal('hide');
							// console.log("Your session is expired.");
					     	location.reload();
						},((timeOut+5)* 1000));
					}
					$('#exampleModal-danger-header').modal('toggle');
				}, error: function(xhr, ajaxOptions, thrownError) {
					console.log("Something went wrong.")
				}
			});
		});
	}
	
	if($("#login").length){
		$('#login').bootstrapValidator({
	        feedbackIcons: {
	            valid: 'glyphicon glyphicon-ok',
	            invalid: 'glyphicon glyphicon-remove',
	            validating: 'glyphicon glyphicon-refresh'
	        },
	        fields: {
	        	username: {
	                validators: {
	                    notEmpty: {
	                        message: 'The username is required'
	                    }
	                }
	            },
	            password: {
	                validators: {
	                    notEmpty: {
	                        message: 'The password is required'
	                    }
	                }
	            }
	        }
	    });
	}
	
	if($("#otp_form").length){
		$('#otp_form').bootstrapValidator({
	        feedbackIcons: {
	            valid: 'glyphicon glyphicon-ok',
	            invalid: 'glyphicon glyphicon-remove',
	            validating: 'glyphicon glyphicon-refresh'
	        },
	        fields: {
	        	otp: {
	                validators: {
	                    notEmpty: {
	                        message: 'The otp is required'
	                    },
	                    integer: {
                        	message: "OTP should have integer only."
                        },
                        stringLength: {
                            max: 5,
                            min: 5,
                            message: 'The OTP must have 5 characters'
                        }
	                }
	            }
	        }
	    });
	}
});
$( document ).ajaxSend(function() {
	  // console.log( "Triggered ajaxSend handler." );
	  window.clearTimeout(showPreExpiredMsg);
	  window.clearTimeout(sessionTimeOut);
});


	



$(document).ready(function(){
	
	if($("#forgetpassword").length){
		$('#forgetpassword').bootstrapValidator({
	        feedbackIcons: {
	            valid: 'glyphicon glyphicon-ok',
	            invalid: 'glyphicon glyphicon-remove',
	            validating: 'glyphicon glyphicon-refresh'
	        },
	        fields: {
	        	hrmsemployeeid: {
	                validators: {
	                    notEmpty: {
	                        message: 'The USERID is required'
	                    }
	                }
	            }
	        }
	    });
	}
});

// toggle password visibility
$('.eye').on('click', function() {
	
  $($(this).children()).toggleClass('fa-eye-slash').toggleClass('fa-eye');
  var x = $(this).siblings('.password');
  if (x.attr('type') == "password") {
	  x.attr('type','text');
  } else {
	  x.attr('type','password');
   // x.type = "password";
  }
  
});



function startLoader() {
	$('body').loading('start');
}
function stopLoader() {
	$(':loading').loading('stop');
}

/*
 * if ( $(".select2").length ) { $('.select2').each(function (i, obj) {
 * console.log(i, obj); if (!$(obj).data('select2')) { $(obj).select2({ width:
 * 'resolve', }); } }); $(".select2").select2({ width: 'resolve', }); }
 */

if ( $("select").length ) {
	$('select').each(function (i, obj) {
	    if (!$(obj).data('select2') && $(obj).hasClass("select2"))
	    {
	        $(obj).select2({ width: 'resolve', });
	    }
	});
}

if ( $("#assignBillUnit").length ) {
	$("#assignBillUnit")/*
						 * .find('[name="billUnits"]') .select2({ width:
						 * 'resolve', placeholder: 'Select Authority',
						 * initSelection: function(element, callback) { } })
						 * .change(function(e) {
						 * $("#assignBillUnit").bootstrapValidator('revalidateField',
						 * 'billUnits'); }) .end()
						 */
	.bootstrapValidator({
		excluded: ':disabled',
		feedbackIcons: {
            valid: 'fa fa-check',
            invalid: 'fa fa-times',
            validating: 'fa fa-sync-alt'
        },
        fields: {
        	authority: {
        		validators: {
        			notEmpty: { // <=== Use notEmpty instead of Callback
								// validator
                        message: 'Please select authority.'
                     }
        		}
        	},
        	hrmsEmployeeId: {
        		validators: {
        			notEmpty: { // <=== Use notEmpty instead of Callback
								// validator
                        message: 'Please select Employee.'
                     }
        		}
        	},
        	billUnits: {
        		selector: '.billUnits',
                validators: {
                    /*
					 * callback: { message: 'Please choose atleast one bill unit ',
					 * callback: function(value, validator) { // Get the
					 * selected options var options =
					 * validator.getFieldElements('billUnits').val(); return
					 * (options != null && options.length > 0); } }
					 */
                    notEmpty: {
                        message: 'Please choose atleast one bill unit.',
                    }
                }
            },
            effectiveFrom: {
        		selector: '.effectiveFrom',
                validators: {
                    date: {
                    	format: "DD/MM/YYYY",
                        message: 'Please select effective from date.',
                    },
                    notEmpty: {
                        message: 'Please select effective from date.',
                    }
                }
            },
            effectiveTo: {
        		selector: '.effectiveTo',
                validators: {
                    date: {
                    	format: "DD/MM/YYYY",
                        message: 'Please select effective to date.',
                    },
                    notEmpty: {
                        message: 'Please select effective to date.',
                    }
                }
            }
        }
	})
	.on("click", ".addButton", function () {
		var $template = $("#clone-row"),
		$clone = $template
					.clone()
					.removeAttr("id")
					.insertAfter($('#assignBillUnit .dark-table tr:last'));
		
		$("form#assignBillUnit .dark-table #effectiveFrom").each(function(index){
			var input = $(this); // This is the jquery object of the input, do what you will
			input.attr("name", "billUnits[" + index + "]." + input.attr("id"));
			$(this).parents("tr").find("td").first().text(parseInt(index)+1);
		});
		$("form#assignBillUnit .dark-table #effectiveTo").each(function(index){
			var input = $(this); // This is the jquery object of the input, do what you will
			input.attr("name", "billUnits[" + index + "]." + input.attr("id"));
		});
		$("form#assignBillUnit .dark-table #billUnits").each(function(index){
			var input = $(this); // This is the jquery object of the input, do what you will
			input.attr("name", "billUnits[" + index + "].billUnit");
		});

		var $select = $('#assignBillUnit .dark-table tr:last').find("#billUnits"),
		$effectiveFrom = $('#assignBillUnit .dark-table tr:last').find("#effectiveFrom"),
		$effectiveTo =  $('#assignBillUnit .dark-table tr:last').find("#effectiveTo");

		$effectiveFrom.datepicker({
			format: 'dd/mm/yyyy',
            altFormat: "dd/mm/yyyy",
            singleDatePicker: true,
            changeMonth: true, 
            changeYear: true,
            autoClose: true,
            minDate: 0
        });
	    $effectiveTo.datepicker({
			format: 'dd/mm/yyyy',
            altFormat: "dd/mm/yyyy",
            singleDatePicker: true,
            changeMonth: true, 
            changeYear: true,
            autoClose: true,
            minDate: 0
        });

		$("#assignBillUnit").bootstrapValidator("addField", $select);
		$("#assignBillUnit").bootstrapValidator("addField", $effectiveFrom);
		$("#assignBillUnit").bootstrapValidator("addField", $effectiveTo);
	}).on("click", ".removeButton", function () {
		var $row = $(this).parents("tr");
		$select = $row.find("#billUnits"),
		$effectiveFrom = $row.find("#effectiveFrom"),
		$effectiveTo =  $row.find("#effectiveTo");
		$row.remove();


		$("#assignBillUnit").bootstrapValidator("removeField", $select);
		$("#assignBillUnit").bootstrapValidator("removeField", $effectiveFrom);
		$("#assignBillUnit").bootstrapValidator("removeField", $effectiveTo);

		$("form#assignBillUnit .dark-table #effectiveFrom").each(function(index){
			var input = $(this); // This is the jquery object of the input, do what you will
			input.attr("name", "billUnits[" + index + "]." + input.attr("id"));
			$(this).parents("tr").find("td").first().text(parseInt(index)+1);
		});
		$("form#assignBillUnit .dark-table #effectiveTo").each(function(index){
			var input = $(this); // This is the jquery object of the input,
									// do what you will
			input.attr("name", "billUnits[" + index + "]." + input.attr("id"));
		});
		$("form#assignBillUnit .dark-table #billUnits").each(function(index){
			var input = $(this); // This is the jquery object of the input,
									// do what you will
			input.attr("name", "billUnits[" + index + "].billUnit");
		});
	}).on('status.field.bv', function(e, data) {
        if ($("#assignBillUnit button[type='submit']").is(":disabled")) {
            // data.bv.disableSubmitButtons(false);
            $("#assignBillUnit button[type='submit']").attr("disabled", false);
        }
    }).on("click", "#submit", function() {
        $("#assignBillUnit").data("bootstrapValidator").validate();
        
        $("form#assignBillUnit .dark-table #effectiveFrom").each(function(index){
			var input = $(this); // This is the jquery object of the input,
									// do what you will
			$("#assignBillUnit").data("bootstrapValidator").revalidateField(input);
		});
		$("form#assignBillUnit .dark-table #effectiveTo").each(function(index){
			var input = $(this); // This is the jquery object of the input,
									// do what you will
			$("#assignBillUnit").data("bootstrapValidator").revalidateField(input);
		});
		$("form#assignBillUnit .dark-table #billUnits").each(function(index){
			var input = $(this); // This is the jquery object of the input, do what you will
			$("#assignBillUnit").data("bootstrapValidator").revalidateField(input);
		});
		var temp = true;
		for (var i = 0; i < $("#assignBillUnit").data("bootstrapValidator").getInvalidFields().length; i++) {
			if ($($("#assignBillUnit").data("bootstrapValidator").getInvalidFields()[i]).parents("form").attr("id") == "assignBillUnit"){
				temp = false;
			}
		}
		console.log(temp);
        if (temp) {
        	// $("#assignBillUnit").data("bootstrapValidator").destroy();
        	console.log($("#assignBillUnit").data("bootstrapValidator"));
        	console.log($("#assignBillUnit").data("bootstrapValidator").defaultSubmit());
        	// $("#assignBillUnit")[0].submit();
        }
    }).on("click", "#reset", function() {
    	$('form#assignBillUnit .dark-table > tbody > tr').not(':first').each(function(index) {
    		$("#assignBillUnit").bootstrapValidator("removeField",$(this).find("#billUnits"));
    		$("#assignBillUnit").bootstrapValidator("removeField",$(this).find("#effectiveTo"));
    		$("#assignBillUnit").bootstrapValidator("removeField",$(this).find("#effectiveFrom"));
    		$(this).remove();
    	});
    });

    $("#assignBillUnit").bootstrapValidator("removeField",$("#clone-row").find("#billUnits"));
    $("#assignBillUnit").bootstrapValidator("removeField",$("#clone-row").find("#effectiveTo"));
    $("#assignBillUnit").bootstrapValidator("removeField",$("#clone-row").find("#effectiveFrom"));
	// $("#assignBillUnit").find('[name="billUnits"]').select2("val", "");
	$("#assignBillUnit").find('#authority').on("change", function() {
		$("#assignBillUnit").find('#billUnits').val(null).trigger('change');
		$("#assignBillUnit").find('#hrmsEmployeeId').val(null).trigger('change');
		if ($(this).val() !== "" && $(this).val() !== null) {
    		$.ajax({
    			"url": getContextPath()+'/assign-bill-unit/get-employees',
                async: false,
                "contentType": "application/json",
                "type": "POST",
                data: JSON.stringify({authority: $(this).val()}),
                success: function (json) {
                   $('#hrmsEmployeeId').find('option').remove();
                   $('#hrmsEmployeeId').trigger('change');
                   if (json != null && json.authority_list != null && json.authority_list && json.authority_list.length > 0) {
                	   for(var k in json.authority_list) {
                		   var newOption = new Option(json.authority_list[k].empname + " (" + json.authority_list[k].hrms_emp_id + ")" , json.authority_list[k].hrms_emp_id, false, false);
                		   $('#hrmsEmployeeId').append(newOption);
                		}
                	   $('#hrmsEmployeeId').val(null).trigger('change');
                   }
                }
    		});
		} else {
			$('#hrmsEmployeeId').find('option').remove();
            $('#hrmsEmployeeId').trigger('change');
		}
	});
	
	$("#assignBillUnit").find('#hrmsEmployeeId').on("change", function() {
		$('#billUnits').val(null);
        $('#billUnits').trigger('change');
		if ($(this).val() !== "" && $(this).val() !== null) {
			$.ajax({
    			"url": getContextPath()+'/assign-bill-unit/get-assigned-units',
                async: false,
                "contentType": "application/json",
                "type": "POST",
                data: JSON.stringify({hrmsEmployeeId: $(this).val()}),
                success: function (json) {
                   var arr = [];
                   if (json.billUnits.length > 0) {
                	   for (var i = 0 ; i < json.billUnits.length ; i++) {
                		   arr.push(json.billUnits[i].billUnit);
                	   }
                   }
                   $('#billUnits').val(arr);
                   $('#billUnits').trigger('change');
                }
    		});
		}
	});
	$("#assignBillUnit").find("#reset").on("click", function() {
		$('#hrmsEmployeeId').val(null);
        $('#hrmsEmployeeId').trigger('change');
        $('#authority').val(null);
        $('#authority').trigger('change');
        $('#billUnits').val(null);
        $('#billUnits').trigger('change');
        $('#assignBillUnit').bootstrapValidator('resetForm', true);
	});

	$("#assignBillUnit").find("#effectiveFrom").datepicker({
		format: 'dd/mm/yyyy',
        altFormat: "dd/mm/yyyy",
        singleDatePicker: true,
        changeMonth: true, 
        changeYear: true,
        autoClose: true,
        minDate: 0
    });
	$("#assignBillUnit").find("#effectiveTo").datepicker({
		format: 'dd/mm/yyyy',
        altFormat: "dd/mm/yyyy",
        singleDatePicker: true,
        changeMonth: true, 
        changeYear: true,
        autoClose: true,
        minDate: 0
    });
    $( document ).on("change", "#effectiveFrom", function () {
    	$("#assignBillUnit").bootstrapValidator("addField", $(this));
    	$("#assignBillUnit").data("bootstrapValidator").revalidateField($(this));
	});
	$( document ).on("change", "#effectiveTo", function () {
		$("#assignBillUnit").bootstrapValidator("addField", $(this));
    	$("#assignBillUnit").data("bootstrapValidator").revalidateField($(this));
	});
    /*$("#assignBillUnit").find("#effectiveFrom").on("change", function() {
    	var from = $(this);
    	var to = $(this).parents("tr").find("#effectiveTo");
    	console.log(from)
    	to.datepicker('option', 'maxDate', from.datepicker('getDate'));
        to.datepicker('option', 'minDate', 0);
    });*/
}
if ($("#esr-pdf-view").length) {
	$( document ).ready(function() {
		$(".sidebar-toggler").trigger( "click" );
	});	
}

if ($("#change-page-number").length) {
	$( document ).ready(function() {
		$( document ).on("click", "#change-page-number", function(e) {
			e.preventDefault();
			if ($("#esr-pdf-view").length) {
				var url = $("#esr-pdf-view iframe").attr("src").split("#")[0] + $(this).attr("href");
				$("#esr-pdf-view").html('<iframe id="secondaryCreate" class="iframe-full-height" src="'+url+'" width="100%" height="100%"></iframe>');
			}
		});
	});
}
if ($("#loginForm").length) {
	$("#loginForm #username").on("keyup", function(){
		$(this).val(inputValueCaseChangeV2("U", $(this).val()));
	});
	$("#loginForm #username").on("blur", function(){
		$(this).val(inputValueCaseChangeV2("U", $(this).val()));
	});
	
	$("#loginForm #password").keypress(function(e) {
		var character = e.keyCode ? e.keyCode : e.which;
		var sftKey = e.shiftKey ? e.shiftKey : ((character == 16) ? true : false);
		
		// Is caps lock on?
	    isCapsLock = (((character >= 65 && character <= 90) && !sftKey) || ((character >= 97 && character <= 122) && sftKey));
		
	 	// Display warning and set css
	    if (isCapsLock == true) {
	    	$("#loginForm .msg").css("display", "block");
	    } else {
	    	$("#loginForm .msg").css("display", "none");
	    }
	});
}


function showdiv()
{
   var mydiv = document.getElementById("birthday-empty");
   mydiv.style.visibility="visible";
}
function hidediv()
{
   var mydiv = document.getElementById("birthday-empty");
   mydiv.style.visibility="hidden";
}

var offset = 0 ;
var limit = 50 ;
var flag = true ;
$(document).ready(function() {
		if($('.marqueeLeft').length>0 && !($('#otp_form').length>0) && !($('#loginForm').length>0)){
			var ajax = $.ajax({
			    type: 'POST',   
			    dataType: "json",
			    url: getContextPath()+'/commons/get-dashboard-message',
			    data: {messageType : 'DM'},
			    success: function(resultData) {          
			    	 if (resultData.messages != null) {
			    		 $.each(resultData.messages, function(i, item) {
			 	        	 	$('.marqueeLeft').append( '&nbsp; <span style="color:'+item.disp_color+'"><i class="fa fa-hand-o-right" aria-hidden="true"></i> '+item.message +'</span> &nbsp;');
			 	         });
			 	         if ($(".marqueeLeft").length) {
							$('.marqueeLeft').marquee({
			 	            	duration: 10000,
			 	            	duplicate: true,
			 	            	direction: 'left',
			 	            	gap: 50,
			 	            	pauseOnHover: true
							});
			 	         }
			    	 }
			    	 $(':loading').loading('stop');
				}
			        
			});
		}
   
   
        
        $('#birthdayList').click(function() {
  		  if (flag) {
  			  var ajax = $.ajax({
  		            type: "POST",
  		            url: getContextPath()+"/ajax/birthday-details",
  		            dataType: "json",
  		            contentType: 'application/json',
  		            data:JSON.stringify({offset: offset,limit:limit}),
  		            success: function (resultData) {
  		            	console.log(resultData);
  		                
  		                console.log("length"+resultData.birthdaylist.length);
  		                if(resultData.birthdaylist.length == 0)
		                {
		                	console.log("Empty Birthday List");
		                	showdiv();
		                }
  		                else if (resultData.birthdaylist.length < limit) {
  							flag = false;
  							// hidediv();
  						}
  		               
  		                $.each(resultData.birthdaylist, function(i, item) {
  		                 		                 
  		                    var $messageBox = $("#messageBox-birthday").clone();
  		                    $messageBox.removeAttr("style");
  		                    $messageBox.find("#employeeName").html(item.empname);
  		                    $messageBox.find("#employeeNumber").html(item.hrms_emp_id);
  		                    $messageBox.find("#employeeDesignation").html(item.desiglongdesc);
  		                    console.log("avavacsac"+item.desiglongdesc);
  		                    $messageBox.find("#employeeDepartment").html(item.department_description);
  		                    // $messageBox.find('#employeeImage').append("<img
							// src='"+getContextPath()+
							// "/file/cris-irhrms/USER_PROFILE/EFXEXND.jpg"+"'
							// class='rounded-circle' alt='photo' width='80'
							// height='60'>");
  		                    $messageBox.find('#employeeImage').attr("src",getContextPath()+item.userprofile);
  		                    		                 
  		                    console.log("avav"+getContextPath()+ "/file/cris-irhrms/USER_PROFILE/EFXEXND.jpg");
  		                    console.log("birthdayJSON"+resultData.birthdaylist); 		                   
  		                    
  		                    $('#birthday-list').append($messageBox);
  		                    
  		                	});
  		                
  		            }
  		        });
  		  }
  		});
  	
  	    $('#birthday-list').on('scroll', function() {
  	        if($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight) {
  	            offset = offset + 10;
  	            if (flag) {
  	            	var ajax = $.ajax({
  			            type: "POST",
  			            url: getContextPath()+"/ajax/birthday-details",
  			            dataType: "json",
  			            contentType: 'application/json',
  			            data:JSON.stringify({offset: offset,limit:limit}),
  			            success: function (resultData) {
  			                   
  							if (resultData.birthdaylist.length < limit) {
  								flag = false;
  							}
  			                $.each(resultData.birthdaylist, function(i, item) {
  			                	   
  			                    var $messageBox = $("#messageBox-birthday").clone();
  			                    $messageBox.removeAttr("style");
  			                    $messageBox.find("#employeeName").html(item.empname);
  			                    $messageBox.find("#employeeNumber").html(item.hrms_emp_id);
  			                    $messageBox.find("#employeeDesignation").html(item.desiglongdesc);
  			                    $messageBox.find("#employeeDepartment").html(item.department_description);
  			                    $('#birthday-list').append($messageBox);
  			                
  			                });
  			            }
  			        });	
  	            }
  	        }
  	    });
  	    
  	
  	  
  	$('#showAll').click(function(){ 
  		if (!($.fn.DataTable.isDataTable('#birthdaydatatable'))) {
  			var ajax = $.ajax({
	            type: "POST",
	            url: getContextPath()+"/ajax/birthday-view-report-details",
	            dataType: "json",
	            contentType: 'application/json',
	            
	            success: function (resultData) { 
	            		            	
	                $.each(resultData.birthdaylist, function(i, item) {	
	                    $('#birthdayListBody').append('<tr><td>'+(i+1)+'</td> <td>'+"<img src='"+getContextPath()+item.userprofile+"' class='img-thumbnail' alt='photo' width='60' height='50'>"+'</td> <td>'+item.empname+ " ( "+item.hrms_emp_id+ " ) "+ '</td> <td>'+item.desiglongdesc+'</td><td>'+item.department_description+'</td> </tr>' );
	                });
	                $('#birthdaydatatable').DataTable();
	             }
	        });
  		}
  		getEmployeeMasterDataForBirthday();
  	});
    /**/
  	
  	$('#birthdaylistByRailwayUnitName').click(function(){ 
  		
  		// alert( "You Clicked Me" );
  		var optionselected = $('#railwayUnitName option:selected').val();
			console.log("optionselected",optionselected);
						
			
			var table = $('#birthdaydatatable').DataTable();
			table.clear();
  		// if (!$.fn.DataTable.isDataTable('#birthdaydatatable')) {
  			
  			var ajax = $.ajax({
	            type: "POST",
	            data:JSON.stringify({optionselected:optionselected}),
	            url: getContextPath()+"/ajax/birthday-details-by-railway-unit",	            
	            dataType: "json",
	            contentType: 'application/json',
	            
	            success: function (resultData) {
	            	
	            	console.log("Checking list by railway Unit"+resultData);
	            	$.each(resultData.birthdaylist, function(i, item) {
	                 
	                   table.row.add( [
	                    	(i+1),
	                    	"<img src='"+getContextPath()+item.userprofile+"' class='img-thumbnail' alt='photo' width='60' height='50'>",
	                    	item.empname + " ( "+item.hrms_emp_id + " ) ",
	                    	item.desiglongdesc,
	                    	item.department_description
	                    ] ).draw( false );
	                  
	                });	               
	                table.draw();	                
	            	}
  				});
			  		
  	});
  	
  	$('#headerNotificationList').click(function(event){
  		if($('#notificationWrapDiv a').length<=0){
	  		$.ajax({
			    type: 'POST',   
			    dataType: "json",
			    url: getContextPath()+'/commons/get-dashboard-message',
			    data: {messageType : null},
			    success: function(resultData) {         
			    	if (resultData != null && resultData.messages) {
			    		var items = [];
						$.each(resultData.messages, function(i, item) {
							$('#notificationWrapDiv').append('<a class="dropdown-item" href="#" style="white-space: normal;"><i class="fa fa-hand-o-right"></i>'+item.message+'</a>');
			 	        });
						if(resultData.messages.length > 2){
							$('#notificationWrapDiv').addClass('scrollable-menu');
						} else {
							$('#notificationWrapDiv').append('<a class="dropdown-item" href="#"></a>');
						}
						$('#no-notifications').hide();
					}
			    	$(':loading').loading('stop');
				},
		        beforeSend: function (xhr)
		        {
		            xhr.setRequestHeader($("meta[name='_csrf_header']").attr("content"), $("meta[name='_csrf']").attr("content"));
		            $('#notificationWrapDiv').loading();
		        },
		        error: function (jqXHR, exception) {
					alertify.error("Some error occurred. Please try again");
		            $(':loading').loading('stop');
				}
			        
			});
  		}
  	});
});


var waitingDialog = waitingDialog || (function ($) {
    'use strict';

	// Creating modal dialog's DOM
	var $dialog = $(
		'<div class="modal fade" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true" style="padding-top:15%; overflow-y:visible;">' +
		'<div class="modal-dialog modal-m">' +
		'<div class="modal-content">' +
			'<div class="modal-header"><h5 style="margin:0;"></h5></div>' +
			'<div class="modal-body">' +
				'<div class="progress progress-striped active" style="margin-bottom:0;"><div class="progress-bar progress-bar-striped progress-bar-animated" style="width: 100%"></div></div>' +
			'</div>' +
		'</div></div></div>');

	return {
		/**
		 * Opens our dialog
		 * 
		 * @param message
		 *            Custom message
		 * @param options
		 *            Custom options: options.dialogSize - bootstrap postfix for
		 *            dialog size, e.g. "sm", "m"; options.progressType -
		 *            bootstrap postfix for progress bar type, e.g. "success",
		 *            "warning".
		 */
		show: function (message, options) {
			// Assigning defaults
			if (typeof options === 'undefined') {
				options = {};
			}
			if (typeof message === 'undefined') {
				message = 'Loading';
			}
			var settings = $.extend({
				dialogSize: 'm',
				progressType: '',
				onHide: null // This callback runs after the dialog was
								// hidden
			}, options);

			// Configuring dialog
			$dialog.find('.modal-dialog').attr('class', 'modal-dialog').addClass('modal-' + settings.dialogSize);
			/* $dialog.find('.progress-bar').attr('class', 'progress-bar');
			if (settings.progressType) {
				$dialog.find('.progress-bar').addClass('progress-bar-' + settings.progressType);
			} */
			$dialog.find('h5').text(message);
			// Adding callbacks
			if (typeof settings.onHide === 'function') {
				$dialog.off('hidden.bs.modal').on('hidden.bs.modal', function (e) {
					settings.onHide.call($dialog);
				});
			}
			// Opening dialog
			$dialog.modal();
		},
		/**
		 * Closes dialog
		 */
		hide: function () {
			$dialog.modal('hide');
		}
	};

})(jQuery);

$('form').on('reset', function(e){
			// console.log("in reset form");
		    $(".server-errors").empty();
		});
function tabStatusDescription(status){
    	var desc='';
    	switch(status){
    		case 'V':	desc="Verified";
	    				break;
	    	case 'VR' :	desc="Returned to DC by Verification Authority";
	    				break;	
	    	case 'AR' :	desc="Returned to DC by Acceptance Authority";
	    				break;	
	    	case 'A' :	desc="Accepted";
	    				break;	
	    	case 'D' :	desc="Draft";
	    				break;	
	    	case 'E' :	desc="Submitted for Verification";
	    				break;	
	    	case 'CE' :	desc="Submitted for Verification";
	    				break;	
	    	case 'DV' :	desc="Returned by Verification Authority";
	    	break;	
	    	case 'DA' :	desc="Accepted";
	    	break;	
	    	case 'DAR' :	desc="Returned by Acceptance Authority";
	    	break;	
	    	case 'DVR' :	desc="Returned by Verification Authority";
	    	break;	
	    	case 'SS' :	desc="Submitted by settlement DC for verification";
			break;
	    	case 'SR' :	desc="Rejected by Settlement DC";
			break;
	    	case 'SV' :	desc="Verified by Verification Authority";
			break;
	    	case 'SVR' :	desc="Rejected by Settlement Verification Authority";
			break;
	    	case 'SA' :	desc=" Accepted by Settlement Acceptance Authority";
			break;
	    	case 'SAR' :	desc="Rejected by Settlement Acceptance Authority";
			break;
	    	case 'DS' :	desc="Details Saved by Employee";
			break;
	    	case 'UR' :	desc="Returned by Unit Admin";
			break;
	    	case 'G' :	desc="PPO generated";
			break;
	    	case 'H' :	desc="Sent to Accounts Section";
			break;
	    	case 'R' :	desc="Rejected by Accounts Section";
			break;
	    	default: desc= "New";
    	}
    	return desc;
    }

function saveFormDataAjax($empForm,actionURL){
	var formData = new FormData();
	var other_data = $empForm.serializeArray();
    $.each(other_data,function(key,input){
    	/*if(input.name!='_csrf') {	formData.append(input.name,input.value.toUpperCase());	}
    	else */
    	formData.append(input.name,input.value);
    });
    var status=$empForm.find("input[name='status']").val();
    $("#recordStatus").html(tabStatusDescription(status));
	$.ajax({
		url: getContextPath() +actionURL,
		type: "post",
		data: formData,
        processData: false,      
        contentType: false,
		success: function (resultData) {
			if(resultData!=null && resultData.result!=null && resultData.result){
				$('<div class="alert alert-success alert-dismissible fade show" role="alert">'+ resultData.message
		            +' </div>').insertBefore($('#tabListDiv'));
				setTimeout(function() {
		   			$(".alert-success").alert('close');
		   		}, 10000);
				if(actionURL.indexOf("-submit") != -1 || status=='E'){
					$empForm.closest('.tab-pane').find('.statusDisplay').html(tabStatusDescription('E'));
					$empForm.find('.statusDisplay').html(tabStatusDescription('E'));
					$empForm.find('.remove-file').hide();
					$empForm.data('bootstrapValidator').resetForm();
					var empFormId='#'+$empForm.attr("id");
					$(empFormId+" :button").prop('disabled',true);
					$(empFormId+" :input").prop('disabled',true);
					if(actionURL.includes('willingness-for-')){
						$empForm.find('.add-row').hide();	
						$empForm.find('.remove-row').hide();	
					}
					if($empForm.attr('id')=='employeeFamilyDetailsId'){
						$empForm.closest('.tab-pane').find('#nofamilyPresent').prop('disabled',true);
						$empForm.closest('.tab-pane').find('#addMember').hide();
						$empForm.closest('.tab-pane').find('.remove-tab').remove();
						
					} else if($empForm.attr('id')=='employeeMedicalInfoId'){
						$empForm.closest('.tab-pane').find('#addMedicalTab').hide();
						$empForm.closest('.tab-pane').find('.remove-med-tab').remove();
					} else if($empForm.attr('id')=='employeeQualificationId') {
						$empForm.find('.addRemoveRow').hide();
					} else if($empForm.attr('id')=='employeeCurrentStatusId') {
						if($('#employeeCurrentStatusId #railwayGroup').val()=='A' || $('#employeeCurrentStatusId #railwayGroup').val()=='B'){
							$('#noMedicalPresentDiv').show();
						}
					}
					$("#reset-basic-form").removeAttr('disabled');
				}
				
			} else { //else1
				if(resultData!=null && resultData.invalidDate!=null){
					$('<div class="alert alert-danger show" role="alert">'+resultData.invalidDate+'</div>').insertBefore($('#tabListDiv'));
				} else if(resultData!=null && resultData.message!=null){
					console.log('Message:'+resultData.message);
					$('<div class="alert alert-danger show" role="alert">'+ resultData.message
				            +' </div>').insertBefore($('#tabListDiv'));
						setTimeout(function() {
				   			$(".alert-success").alert('close');
				   		}, 10000);
				} else { //nested else
					//console.log("error catched")
					$('<div class="alert alert-danger show" role="alert">Some error Occured. Please try again</div>').insertBefore($('#tabListDiv'));
				}
				setTimeout(function() {
			   		$(".alert-danger").alert('close');
			   	}, 10000);
			}
			$(".app-body").animate({ scrollTop: 0 }, "fast", function(){
     	        $(".app-body").off("scroll mousedown wheel DOMMouseScroll mousewheel keyup touchmove");
     	    });
			if($empForm.attr('id')=='employeeMedicalInfoId')	{
				$('#medicalType0').attr('disabled', true);
				if($('#noMedicalPresent').prop('checked')==true){
					$('#medicallyFitCertDate0').attr('disabled', true);
					$('#medicalClassification0').attr('disabled', true);
				}
			}
            $(':loading').loading('stop');
		},
        beforeSend: function (xhr){
            xhr.setRequestHeader($("meta[name='_csrf_header']").attr("content"), $("meta[name='_csrf']").attr("content"));
            $('.app').loading();
        },
       	error: function(xhr, ajaxOptions, thrownError) {
            alertify.error("Some error occured please try again");
			if($empForm.attr('id')=='employeeMedicalInfoId'){
				$('#medicalType0').attr('disabled', true);
				if($('#noMedicalPresent').prop('checked')==true){
					$('#medicallyFitCertDate0').attr('disabled', true);
					$('#medicalClassification0').attr('disabled', true);
				}
			}
            $(':loading').loading('stop');
        }
	});


}

/*
 * function rlyUserCountForZone(String rlyUnit){ var ajax = $.ajax({ type:
 * 'POST', async: false, // data: {employeeId: employeeId}, url:
 * getContextPath()+'/ajax/get_rly_user_prd', dataType: "json", contentType:
 * 'application/json', data:{rlyUnit:rlyUnit}, success: function (resultData) {
 * 
 * $.each(resultData.rlyCountlist, function(i, item) {
 * $('#rlyUserCountForZoneBody').append('<tr> <td>'+item.user_type+ '</td>
 * <td>'+item.total_users+'</td><td>'+item.date_last_created+'</td> </tr>' );
 * 
 * }); } }); }
 */

/**
 * function to re-send OTP for transaction
 * 
 * @param operation
 * @returns
 */
function resendOtpForTransaction(operation ){
	$.ajax({
        url: getContextPath() + "/user-profile/resend-otp-for-transaction",
        type: "post",
        dataType: "json",
        async: false,
        data: {operation: operation },
        success: function (resultData) {
        	console.log(resultData);
        	if(resultData.result==true){
        		$('#otpResent').html('OTP resent succesfully').show();
        	} else $('#otpResent').html('OTP was not sent').show();
        	$(':loading').loading('stop');
        },
        beforeSend: function (xhr)
        {
            xhr.setRequestHeader($("meta[name='_csrf_header']").attr("content"), $("meta[name='_csrf']").attr("content"));
            $('.app').loading();
        },
       	error: function(xhr, ajaxOptions, thrownError) {
            alertify.error("Some error occured please try again");
            $(':loading').loading('stop');
            $('#otpResent').html('Otp was not sent').show();
        }
    });
}

$(document).ready(function(){
	if ($('#resendTxnOtp').length > 0) {
		$('#resendTxnOtp').click(function(e){
			e.preventDefault();
			resendOtpForTransaction($('#operationInput').val());
		})
	}
});
$(document).on('change','input , select', function() { 
	   $countinput= $(this).closest('form').find(".countinput");
	   if($countinput!=null){
	  	 countBlankFieldInForm($countinput);
	   }
    });


function countBlankFieldInForm($countinput){
	   totalInputLen=0;
	   totalSelectLen=0;
	   totalUploadLen=0;
	   totalInput=$countinput.closest('form').find("input[type!='hidden'][type!='button'][type!='submit'][type!='file']")
	   .filter(function() {return !$(this).hasClass("tt-hint");});
	   totalInput.each(function() {
		   //console.log("value is "+$(this).val());
		   if($(this).val()==""){
			   totalInputLen++;
			   }
		 });
		 
	   $countinput.closest('form').find("select").filter(function() {return !this.id.match(/-opt/);})	
	   .each(function() {
		   //console.log("value is "+$(this).val());
		   if($(this).val()==""){
			   totalSelectLen++;
			   }
		 });
	   /* totalInputLen=$countinput.closest('form').find("input[type!='hidden'][type!='button'][type!='submit']")
	   .filter(function() {return !$(this).hasClass("tt-hint") || !!$(this).val("");})
	   ; */
	   $countinput.closest('form').find(".file-view").closest('.row').find("input[type='hidden']")
	   .each(function() {
		   //console.log("value is "+$(this).val());
		   if($(this).val()==""){
			   totalUploadLen++;
			   }
		 }); 
	   
	   
	   //console.log("totaluploadlen "+totalUploadLen);
	    $countinput.find('#blank').html(totalInputLen+totalSelectLen+totalUploadLen);
	   }

	function getEmployeeDcVaAndAa(hrmsEmpID){
		var result=null;
		console.log("getEmployeeDcVaAndAa",hrmsEmpID);
		if(hrmsEmpID!=null && hrmsEmpID!=""){
			$.ajax({
		        url: getContextPath() + "/commons/get-employee-Dc-Va-Aa-Details",
		        type: "post",
		        dataType: "json",
		        async: false,
		        data: {empHrmsId: hrmsEmpID },
		        success: function (resultData) {
		        	result=resultData;
		        },
		        beforeSend: function (xhr)
		        {
		            xhr.setRequestHeader($("meta[name='_csrf_header']").attr("content"), $("meta[name='_csrf']").attr("content"));
		         }
		       	
		    });
		}
		return result;
	}
